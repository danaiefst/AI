/*****************************************

 * 27/03/2003

 *

 * Copyright (C) 1999-2003 Ugo Chirico

 * http://www.ugochirico.com

 *

 * This is free software; you can redistribute it and/or

 * modify it under the terms of the Affero GNU General Public License

 * as published by the Free Software Foundation; either version 3

 * of the License, or any later version.

 *

 * This program is distributed in the hope that it will be useful,

 * but WITHOUT ANY WARRANTY; without even the implied warranty of

 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the

 * Affero GNU General Public License for more details.

 *

 * You should have received a copy of the Affero GNU General Public License

 * along with this program; if not, write to the Free Software

 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

 *****************************************/



package com.ugos.jiprolog.extensions.system;



import com.ugos.jiprolog.engine.*;



import java.util.*;

import java.io.*;



public class Time8 extends JIPXCall

{

    public final boolean unify(final JIPCons input, Hashtable varsTbl)

    {

        JIPTerm millis = input.getNth(1);



        if (millis instanceof JIPVariable)

        {

            if(!((JIPVariable)millis).isBounded())

            {

                throw new JIPInstantiationException(1);

            }

            else

            {

                millis = ((JIPVariable)millis).getValue();

            }

        }

        if (!(millis instanceof JIPNumber))

        {

            throw new JIPTypeException(JIPTypeException.INTEGER, millis);

        }



        final GregorianCalendar calendar = new GregorianCalendar();

        calendar.setTime(new Date((long)((JIPNumber)millis).getDoubleValue()));



        final JIPNumber hour   = JIPNumber.create(calendar.get(GregorianCalendar.HOUR_OF_DAY));

        final JIPNumber min    = JIPNumber.create(calendar.get(GregorianCalendar.MINUTE));

        final JIPNumber sec    = JIPNumber.create(calendar.get(GregorianCalendar.SECOND));

        final JIPNumber milsec = JIPNumber.create(calendar.get(GregorianCalendar.MILLISECOND));

        final JIPNumber year   = JIPNumber.create(calendar.get(GregorianCalendar.YEAR));

        final JIPNumber month  = JIPNumber.create(calendar.get(GregorianCalendar.MONTH) + 1);

        final JIPNumber day    = JIPNumber.create(calendar.get(GregorianCalendar.DAY_OF_MONTH));





        return

            input.getNth(2).unify(year, varsTbl) &&

            input.getNth(3).unify(month, varsTbl) &&

            input.getNth(4).unify(day, varsTbl) &&

            input.getNth(5).unify(hour, varsTbl) &&

            input.getNth(6).unify(min, varsTbl) &&

            input.getNth(7).unify(sec, varsTbl) &&

            input.getNth(8).unify(milsec, varsTbl);

    }



    public boolean hasMoreChoicePoints()

    {

        return false;

    }

}



