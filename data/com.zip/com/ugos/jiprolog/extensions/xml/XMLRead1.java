/*

 * 15/10/2002

 *

 * Copyright (C) 2002 Ugo Chirico

 *

 * This is free software; you can redistribute it and/or

 * modify it under the terms of the Affero GNU General Public License

 * as published by the Free Software Foundation; either version 3

 * of the License, or any later version.

 *

 * This program is distributed in the hope that it will be useful,

 * but WITHOUT ANY WARRANTY; without even the implied warranty of

 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the

 * Affero GNU General Public License for more details.

 *

 * You should have received a copy of the Affero GNU General Public License

 * along with this program; if not, write to the Free Software

 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

 */





package com.ugos.jiprolog.extensions.xml;



import com.ugos.jiprolog.engine.*;



import java.io.*;

import java.util.*;



import org.xml.sax.*;

import org.w3c.dom.*;



import javax.xml.parsers.DocumentBuilderFactory;

import javax.xml.parsers.DocumentBuilder;



public class XMLRead1 extends JIPXCall

{

    public boolean unify(JIPCons input, Hashtable varsTbl)

    {

        JIPTerm term = input.getNth(1);

        if(term instanceof JIPVariable)

            if(((JIPVariable)term).isBounded())

                term = ((JIPVariable)term).getValue();





        JIPTerm xmlDoc = createXMLTerm(String.valueOf(getJIPEngine().getCurrentInputStreamHandle()));



        return term.unify(xmlDoc, varsTbl);

    }



    public boolean hasMoreChoicePoints()

    {

        return false;

    }



    JIPTerm createXMLTerm(String strStreamName)

    {

        Document xmldoc;

        try

        {

        	DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();

    		DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();



            xmldoc = dBuilder.parse(new InputSource(strStreamName));





            String strVer;

            try

            {

                strVer = xmldoc.getXmlEncoding();

            }

            catch(Throwable ex)

            {

                strVer = "1.0";

            }



            String strEnc;

            try

            {

                strEnc = xmldoc.getInputEncoding();

            }

            catch(Throwable ex)

            {

                strEnc  = "UTF-8";

            }



            String strProlog = "[[version = '" + strVer + "'";



            if(strEnc != null)

                strProlog += ", encoding = '" + strEnc + "'";



            strProlog += "]";



            DocumentType docType = xmldoc.getDoctype();

            if(docType != null)

            {

                String strDTD = createXMLTerm(docType);

                strProlog += ", " + strDTD;

            }

            else

            {

                strProlog += ", []";

            }



            strProlog += "]";





            Element doc = xmldoc.getDocumentElement();



            String strRoot = createXMLTerm(doc);



            String strDoc = "xml_document(" + strProlog + ", " + strRoot + ")";

            JIPTerm xmlDocTerm = getJIPEngine().getTermParser().parseTerm(strDoc);

            return xmlDocTerm;

        }

        catch(JIPSyntaxErrorException ex)

        {

            throw new JIPRuntimeException(4002, ex.getMessage());

        }

        catch(SAXException ex)

        {

            throw new JIPRuntimeException(4003, "SAX Exception: " + ex.getMessage());

        }

        catch(Exception ex)

        {

            throw new JIPJVMException(ex);

        }

    }



    private static String doubleQuote(String str)

    {

        int nPos = 0;

        int nBegin = 0;

        while(nPos > -1)

        {

            nPos = str.indexOf('\'', nBegin);

            if(nPos != -1)

            {

                str = str.substring(0, nPos) + '\'' + str.substring(nPos, str.length());

                nBegin = nPos + 2;

            }

        }



        return str;

    }



    private static String createXMLTerm(Node n) throws SAXException

    {

        int type = n.getNodeType();

        switch (type)

        {

            case Node.CDATA_SECTION_NODE:

                CDATASection cdata = (CDATASection)n;

                if(cdata.getData().equals("\n"))

                    return null;

                else

                    return "xml_cdata('" + doubleQuote(cdata.getData().trim()) + "')";



            case Node.TEXT_NODE:

                Text text = (Text)n;

                if(text.getData().equals("\n"))

                    return null;

                else

                    return "xml_text('" + doubleQuote(text.getData().trim()) + "')";



            case Node.COMMENT_NODE:

                Comment comment = (Comment)n;

                if(comment.getData().equals("\n"))

                    return null;

                else

                    return "xml_comment('" + doubleQuote(comment.getData().trim()) + "')";



            case Node.ELEMENT_NODE:

                Element elem = (Element)n;

                String strName = elem.getNodeName();



                String strElement = "xml_element('" + strName + "'";



                NamedNodeMap attrs = elem.getAttributes();

                if(attrs != null)

                    strElement += ", [" + createAttrList(attrs) + "], ";

                else

                    strElement += ", [], ";



                String strChildren = "";

                for (Node child = n.getFirstChild(); child != null;

                         child = child.getNextSibling())

                {

                    String strChild = createXMLTerm(child);

                    if(strChild != null)

                    {

                        strChildren += (strChildren.equals("") ? "" : ", ") + createXMLTerm(child);

                    }

                }



                strElement += "[" + strChildren + "])";



                return strElement;



            case Node.PROCESSING_INSTRUCTION_NODE:

                ProcessingInstruction pi = (ProcessingInstruction)n;

                if(pi.getData().equals("\n"))

                    return null;

                else

                    return "xml_pi('" + pi.getNodeName() + "', '" + doubleQuote(pi.getData().trim()) + "')";



            case Node.DOCUMENT_TYPE_NODE:

                DocumentType docType = (DocumentType)n;



                strElement = "xml_doctype('" + docType.getNodeName() + "', [";



                if(docType.getPublicId() != null)

                {

                    strElement += " 'PUBLIC' = '" + doubleQuote(docType.getPublicId()) + "'";

                }



                if(docType.getSystemId() != null)

                {

                    if(docType.getPublicId() != null)

                        strElement += ", ";



                    strElement += " 'SYSTEM' = '" + doubleQuote(docType.getSystemId()) + "'";

                }



                strElement += "], ";



                String strInternalSubset = docType.getInternalSubset();



                if(strInternalSubset != null)

                {

                    int nBegin = 0;

                    int nPos = strInternalSubset.indexOf('\'');

                    String strAux = "";



                    while(nPos > -1)

                    {

                        strAux += strInternalSubset.substring(nBegin, nPos) + "'";

                        nBegin = nPos;

                        nPos = strInternalSubset.indexOf('\'', nBegin + 1);

                    }



                    strAux += strInternalSubset.substring(nBegin);



                    strElement += "['" + strAux + "']";

                }

                else

                {

                    strElement += "[]";

                }



                strElement += ")";



                return strElement;



            default:

                throw new JIPRuntimeException(4001, "Unsupported Tag: " + n.toString());

        }

    }



    private static String createAttrList(NamedNodeMap attrMap)

    {

        String strAttrs = "";

        for (int i = 0; i < attrMap.getLength(); i++)

        {

            Attr attr = (Attr)attrMap.item(i);

            strAttrs += "xml_attribute('" + attr.getName() + "', '" + doubleQuote(attr.getValue()) + "')";

            if(i < attrMap.getLength() - 1)

                strAttrs += ", ";

        }



        return strAttrs;

    }

}

