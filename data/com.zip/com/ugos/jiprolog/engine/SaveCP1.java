/**

 *

 */

package com.ugos.jiprolog.engine;



import java.util.Hashtable;



/**

 * @author UgoChirico

 *

 */

public class SaveCP1 extends BuiltIn {





	@Override

	public boolean unify(Hashtable<Variable, Variable> varsTbl)

	{

		PrologObject param = getParam(1);



        final WAM.Node curNode = getWAM().getCurNode();



		return param.unify(Expression.createNumber(curNode.hashCode()), varsTbl);

	}



	@Override

	public boolean hasMoreChoicePoints()

	{

		return false;//wam != null;

	}

}

