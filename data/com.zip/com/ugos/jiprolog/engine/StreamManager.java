/*

 * 23/04/2014

 *

 * Copyright (C) 1999-2014 Ugo Chirico

 *

 * This is free software; you can redistribute it and/or

 * modify it under the terms of the Affero GNU General Public License

 * as published by the Free Software Foundation; either version 3

 * of the License, or any later version.

 *

 * This program is distributed in the hope that it will be useful,

 * but WITHOUT ANY WARRANTY; without even the implied warranty of

 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the

 * Affero GNU General Public License for more details.

 *

 * You should have received a copy of the Affero GNU General Public License

 * along with this program; if not, write to the Free Software

 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

 */



package com.ugos.jiprolog.engine;



import java.io.ByteArrayInputStream;

import java.io.ByteArrayOutputStream;

import java.io.File;

import java.io.FileInputStream;

import java.io.FileNotFoundException;

import java.io.FileOutputStream;

import java.io.IOException;

import java.io.InputStream;

import java.io.InputStreamReader;

import java.io.ObjectInputStream;

import java.io.OutputStream;

import java.io.Reader;

import java.net.URI;

import java.net.URISyntaxException;

import java.net.URL;

import java.util.Vector;

import java.util.zip.ZipEntry;

import java.util.zip.ZipFile;



public class StreamManager

{

	private static StreamManager defaultStreamManager;

	private static StreamManager streamManager;



	static

	{

		defaultStreamManager = new StreamManager();

	}



	protected StreamManager()

	{



	}



	public static StreamManager getDefaultStreamManager()

	{

		return defaultStreamManager;

	}



	public static StreamManager getStreamManager()

	{

		if(streamManager == null)

		{

			return defaultStreamManager;

		}



		return streamManager;

	}



	public static void setStreamManager(StreamManager streamManager)

	{

		StreamManager.streamManager = streamManager;

	}



    public InputStream getInputStream(String strFilePath, String strBasePath, String[] strFileName, String[] strCurDir) throws IOException

    {

        InputStream ins = null;



        try

        {

            ins = getInputStream(strFilePath, strFileName, strCurDir);

        }

        catch(IOException ex)

        {



            if(strBasePath.toUpperCase().startsWith("JAR://"))

                ins = getInputStream(strBasePath + "#" + strFilePath, strFileName, strCurDir);

            else if(strBasePath.toUpperCase().startsWith("HTTP://") || strBasePath.toUpperCase().startsWith("HTTPS://"))

                ins = getInputStream(strBasePath + "/" + strFilePath, strFileName, strCurDir);

            else if(strBasePath.toUpperCase().startsWith("INTERNAL://"))

                ins = getInputStream(strBasePath + "/" + strFilePath, strFileName, strCurDir);

            else

                ins = getInputStream(strBasePath + File.separator + strFilePath, strFileName, strCurDir);

        }



        return ins;

    }



    public OutputStream getOutputStream(String strFilePath, String strBasePath, boolean bAppend, String[] strFileName, String[] strCurDir) throws IOException

    {

        OutputStream outs = null;



        try

        {

            outs = getOutputStream(strFilePath, bAppend, strFileName, strCurDir);

        }

        catch(IOException ex)

        {

            if(strBasePath.toUpperCase().startsWith("JAR://"))

                outs = getOutputStream(strBasePath + "#" + strFilePath, bAppend, strFileName, strCurDir);

            else if(strBasePath.toUpperCase().startsWith("HTTP://"))

                outs = getOutputStream(strBasePath + "/" + strFilePath, bAppend, strFileName, strCurDir);

            else

                outs = getOutputStream(strBasePath + File.separator + strFilePath, bAppend, strFileName, strCurDir);

        }





        return outs;

    }



    private InputStream getInputStream(String strPath, String[] strFileName, String[] strCurDir) throws IOException, SecurityException

    {

        if(strPath.charAt(0) == 39 || strPath.charAt(0) == 34)

        {

            strPath = strPath.substring(1, strPath.length() - 1);

        }



        if(strPath.toUpperCase().startsWith("HTTP://") || strPath.toUpperCase().startsWith("HTTPS://"))

        {

            URL url = new URL(strPath);

            strFileName[0] = strPath.substring(7);

            strCurDir[0] = "http://" + url.getHost() + File.separatorChar;

            return url.openStream();

        }

        else if(strPath.toUpperCase().startsWith("FILE:/"))

        {

        	URI uri;

        	URL url;

			try {

				uri = new URI(strPath);

				url = uri.toURL();

			} catch (URISyntaxException e) {

				url = new URL(strPath);

			}



            strPath = strPath.substring(6).replace('\\', File.separatorChar);

            strPath = strPath.replace('/', File.separatorChar);

            strFileName[0] = strPath;//.substring(6);

            int nSepPos = strPath.lastIndexOf(File.separatorChar);

            if(nSepPos < 0)

            {

                throw new FileNotFoundException(strPath);

            }

            strCurDir[0] = "FILE:/" + strPath.substring(0, nSepPos) + File.separatorChar;

            return url.openStream();

        }

        else if(strPath.toUpperCase().startsWith("JAR://"))

        {

            int nSepPos = strPath.indexOf('#');

            if(nSepPos < 0)

            {

                throw new FileNotFoundException(strPath);

            }

            String strFile = strPath.substring(nSepPos + 1);

            strPath = strPath.substring(6, nSepPos);

            strCurDir[0] = strFile + "#";

            strFileName[0] = strPath;

            ZipFile zipFile = new ZipFile(strPath);

            ByteArrayOutputStream outs;

            try

            {

                strFile = strFile.replace((char)92, '/');

                ZipEntry entry = zipFile.getEntry(strFile);

                if(entry == null)

                {

                    strFile = strFile.replace('/', (char)92);

                    entry = zipFile.getEntry(strFile);

                }



                if(entry == null)

                {

                    strPath = strPath.replace('\\', '/');

                    throw new FileNotFoundException(strPath);

                }



                Reader ins = new InputStreamReader(zipFile.getInputStream(entry));

                outs = new ByteArrayOutputStream();

                int c;

                while((c = ins.read()) != -1)

                {

                    outs.write(c);

                }

                zipFile.close();

            }

            catch(IOException ex)

            {

                zipFile.close();

                throw ex;

            }



            ByteArrayInputStream bins = new ByteArrayInputStream(outs.toByteArray());



            return bins;

        }

        else if(strPath.toUpperCase().startsWith("INTERNAL://"))

        {

        	strCurDir[0] = strPath.substring(0, strPath.lastIndexOf('/'));



            strPath = strPath.substring(11);

            strFileName[0] = strPath;//.substring(6);



            InputStream ins = StreamManager.class.getResourceAsStream("/" + strPath);

            return ins;

        }

	    else

	    {



	        File file = new File(new File(strPath).getCanonicalPath());



	        strFileName[0] = file.getCanonicalPath();//strPath;

	        strCurDir[0]   = file.getParent() + File.separatorChar;

	        return new FileInputStream(file);

	    }

    }



    private OutputStream getOutputStream(String strPath, boolean bAppend, String[] strFileName, String[] strCurDir) throws IOException

    {

        if(strPath.charAt(0) == 39 || strPath.charAt(0) == 34)

        {

            strPath = strPath.substring(1, strPath.length() - 1);

        }



        if(strPath.toUpperCase().startsWith("HTTP://") || strPath.toUpperCase().startsWith("HTTPS://"))

        {

        	throw new JIPTypeException(JIPTypeException.URL, Atom.createAtom(strPath));

        }

        else if(strPath.toUpperCase().startsWith("FILE:/"))

        {

            URL url = new URL(strPath);

            strFileName[0] = strPath.substring(8);

            int nSepPos = strPath.lastIndexOf(File.separatorChar);

            if(nSepPos < 0)

            {

                throw new FileNotFoundException(strPath);

            }

            strCurDir[0] = strPath.substring(0, nSepPos) + File.separatorChar;

            return url.openConnection().getOutputStream();

        }

        else if(strPath.toUpperCase().startsWith("JAR://"))

        {

        	throw new JIPTypeException(JIPTypeException.FILE, Atom.createAtom(strPath));

        }

        else

        {

            File file = new File(new File(strPath).getCanonicalPath());

            strFileName[0] = file.getCanonicalPath();//strPath;

            strCurDir[0]   = file.getParent() + File.separatorChar;

            return new FileOutputStream(file.getAbsolutePath(), bAppend);

        }

    }

}



