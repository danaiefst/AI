/**

 *

 */

package com.ugos.jiprolog.engine;



/**

 * @author UgoChirico

 *

 */

public interface StreamPosition

{

	public int getLineNumber();

}

