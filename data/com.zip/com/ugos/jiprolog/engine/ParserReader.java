/*

 * 23/04/2014

 *

 * Copyright (C) 1999-2014 Ugo Chirico

 *

 * This is free software; you can redistribute it and/or

 * modify it under the terms of the Affero GNU General Public License

 * as published by the Free Software Foundation; either version 3

 * of the License, or any later version.

 *

 * This program is distributed in the hope that it will be useful,

 * but WITHOUT ANY WARRANTY; without even the implied warranty of

 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the

 * Affero GNU General Public License for more details.

 *

 * You should have received a copy of the Affero GNU General Public License

 * along with this program; if not, write to the Free Software

 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

 */

package com.ugos.jiprolog.engine;



import java.io.IOException;

import java.io.Reader;



import com.ugos.io.PushbackLineNumberInputStream;



class ParserReader extends Reader

{

    private int m_nLastChar = -1;

    private boolean m_bEOF;



    private PushbackLineNumberInputStream m_ins;





    public ParserReader(final PushbackLineNumberInputStream ins)

    {

        m_ins = ins;



        m_bEOF = false;

    }



    public final int getLineNumber()

    {

        return m_ins.getLineNumber();

    }



    public final int getColumn()

    {

        return m_ins.getColNumber();

    }



    public final int getRead()

    {

        return m_ins.getRead();

    }



    public final int read() throws IOException

    {

        int c;

            c = m_ins.read();



              m_nLastChar = c;



        if( c == -1)

            m_bEOF = true;



        return c;

    }



    public void unread(int c)

    {

    	try {

			m_ins.unread(c);

		} catch (IOException e) {

			e.printStackTrace();

		}

    }



    public boolean eof()

    {

        return m_bEOF;

    }



    public void close() throws IOException

    {

        m_ins.close();

    }



    /* (non-Javadoc)

     * @see java.io.Reader#read(char[], int, int)

     */

    public int read(char[] arg0, int arg1, int arg2) throws IOException

    {

       int c = 0;

       int start = arg1;

       while(arg2 > 0 &&  (c = read()) != -1)

       {

           arg0[arg1] = (char)c;

           arg1++;

           arg2--;

       }



       return arg1 - start;

    }





}



