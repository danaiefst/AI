/**

 *

 */

package com.ugos.jiprolog.engine;



/**

 * @author UgoChirico

 *

 */

public class JIPDebugger

{

	public static boolean debug = false;

}

