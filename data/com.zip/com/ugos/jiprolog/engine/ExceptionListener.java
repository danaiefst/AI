package com.ugos.jiprolog.engine;



public interface ExceptionListener {

	public boolean notifyException(JIPRuntimeException ex);

	public Catch3 getCallingTerm();

}
