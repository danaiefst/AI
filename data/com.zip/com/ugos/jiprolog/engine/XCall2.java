/*

 * 23/04/2014

 *

 * Copyright (C) 1999-2014 Ugo Chirico

 *

 * This is free software; you can redistribute it and/or

 * modify it under the terms of the Affero GNU General Public License

 * as published by the Free Software Foundation; either version 3

 * of the License, or any later version.

 *

 * This program is distributed in the hope that it will be useful,

 * but WITHOUT ANY WARRANTY; without even the implied warranty of

 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the

 * Affero GNU General Public License for more details.

 *

 * You should have received a copy of the Affero GNU General Public License

 * along with this program; if not, write to the Free Software

 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

 */



package com.ugos.jiprolog.engine;



import java.util.*;



final class XCall2 extends BuiltIn

{

    private JIPXCall      m_exObj;

    private static Hashtable<String, Class> classTable = new Hashtable<String, Class>();



    public final boolean unify(final Hashtable<Variable, Variable> varsTbl)

    {

        if (m_exObj == null)  // Called for the first time

        {

            final PrologObject exClass = getRealTerm(getParam(1));



            String strXClassName;

            if(exClass instanceof Atom)

                strXClassName = ((Atom)exClass).getName();

            else

                throw new JIPTypeException(JIPTypeException.ATOM_OR_STRING, exClass);



            m_exObj = createXCall(strXClassName);



            m_exObj.init(this);

        }



        final PrologObject params = getRealTerm(getParam(2));

        if(!(params instanceof List))

        	throw new JIPTypeException(JIPTypeException.LIST, params);



        JIPCons exParams = new JIPCons(((List)params).getConsCell());



        Hashtable<JIPVariable, JIPVariable> jipVarsTable = new Hashtable<JIPVariable, JIPVariable>();

        boolean unify = m_exObj.unify(exParams, jipVarsTable);



        if(unify)

        {

        	Variable var;

        	for(JIPVariable jvar : jipVarsTable.values())

        	{

        		var = (Variable)jvar.getTerm();

        		varsTbl.put(var, var);

        	}

        }



        return unify;

    }





    public final boolean hasMoreChoicePoints()

    {

        return m_exObj == null ? true : m_exObj.hasMoreChoicePoints();

    }



    @SuppressWarnings("rawtypes")

	protected static final JIPXCall createXCall(String strXClassName)

    {

        try

        {



            JIPXCall exObj;

            Class xclass;

            if(classTable.containsKey(strXClassName))

            {

            	xclass = classTable.get(strXClassName);

            }

            else if((JIPEngine.getClassLoader()) != null)

            {

            	xclass = JIPEngine.getClassLoader().loadClass(strXClassName);

            	classTable.put(strXClassName, xclass);

            }

            else

            {

            	xclass = Class.forName(strXClassName);

            	classTable.put(strXClassName, xclass);

            }



            exObj = (JIPXCall)xclass.newInstance();



            return exObj;

        }

        catch(ClassNotFoundException ex)

        {

        	throw JIPExistenceException.createProcedureException(Atom.createAtom(strXClassName));

        }

        catch(IllegalAccessException ex)

        {

        	throw JIPExistenceException.createProcedureException(Atom.createAtom(strXClassName));

        }

        catch(InstantiationException ex)

        {

        	throw JIPExistenceException.createProcedureException(Atom.createAtom(strXClassName));

        }

        catch(ClassCastException ex)

        {

        	throw JIPExistenceException.createProcedureException(Atom.createAtom(strXClassName));

        }

        catch(NoClassDefFoundError ex)

        {

        	ex.printStackTrace();

        	throw JIPExistenceException.createProcedureException(Atom.createAtom(strXClassName));

        }

    }

}

