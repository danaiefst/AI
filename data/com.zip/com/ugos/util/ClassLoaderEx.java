/*************************

 *

 * 09/19/2002

 *

 * Copyright (C) 2002 Ugo Chirico

 *

 * This is free software; you can redistribute it and/or

 * modify it under the terms of the Affero GNU General Public License

 * as published by the Free Software Foundation; either version 3

 * of the License, or any later version.

 *

 * This program is distributed in the hope that it will be useful,

 * but WITHOUT ANY WARRANTY; without even the implied warranty of

 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the

 * Affero GNU General Public License for more details.

 *

 * You should have received a copy of the Affero GNU General Public License

 * along with this program; if not, write to the Free Software

 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

 **************************/



package com.ugos.util;



import java.io.*;

import java.util.*;



/**

 * <br>

 * Questa classe implementa una particolare estensione al classloader

 * @author       Ugo Chirico www.ugosweb.com

 */

public class ClassLoaderEx extends ClassLoader

{

    final private ClassProvider m_provider;

    

      /**

      * Costruttore.<br>

      *

      * @param  provider instanza di un ClassProvider che fornisce le classi.

      */

    public ClassLoaderEx(final ClassProvider provider)

    {

        m_provider = provider;

    }



    /**

    * Carica una classe.<br>

    * Il metodo viene invocato direttamente dal metodo pubblico loadClass(String name) in

    * java.lang.ClassLoader. <br>

    * @param     nameClass    nome della classe.

    * @param     resolve true o false se la classe va risolta o meno. In genere una classe e da

    *                        risolvere se contiene riferimeni ad altre classi.<br>

    *                        Il loader imposta correttamente ed automaticamente questo parametro ad ogni chiamata.<br>

    *

    * @exception ClassNotFoundException  classe non trovata.

    * @exception ClassFormatError    errore nel convertire la classe da array a  Class.

    * @return Class - la classe richiesta.

    */

    protected Class loadClass(String nameClass, boolean resolve)

        throws ClassNotFoundException, ClassFormatError

    {

        

        byte[] classBytes = null;

        Class classClass = null;

        

        try

        {

            classClass = findLoadedClassEx(nameClass);

        }

        catch(ClassNotFoundException cnfe)

        {

            try

            {

                classBytes = loadClassFromProvider(nameClass);

                

                try

                {

                    int dot = nameClass.lastIndexOf('.');

                    String pkgName = (dot < 0) ? null : nameClass.replace('/', '.').substring(0, dot);

                    if (pkgName != null && getPackage(pkgName) == null)

                    {

                        definePackage(pkgName, null, null, null, null, null, null, null);

                    }//end if there is a Package but it has not yet been defined

                }

                catch(Throwable th)

                {

                }



                classClass = defineClass(nameClass, classBytes, 0, classBytes.length);

                if (classClass == null)

                    throw new ClassFormatError(nameClass);

            }

            catch(IOException ex)

            {

                throw new ClassNotFoundException(nameClass);

            }

       }

        

        

            

        if (resolve)

            resolveClass(classClass);

                

        return classClass;

    }

      

    /**

    * Carica una classe dal provider e la restuituisce come array di byte.

    * @param     nameClass    nome della classe.

    * @exception ClassNotFoundException   Classe non trovata.

    * @exception IOException          see java.io.IOException.

    * @return        byte[] Array di byte che rappresenta la classe.

    */

    protected final byte[] loadClassFromProvider(final String nameClass)

            throws ClassNotFoundException, IOException

    {

        return m_provider.loadClass(nameClass);

    }

    

    /**

    * Cerca una risorsa dal provider e restuituisce il corrispondente inputstream.

    * @param     name    nome della risorsa.

    * @return    InputStream della risorsa.

    */

    public InputStream getResourceAsStream(String name)

    {

        InputStream ins = null;

        

        try

        {

            byte[] buffer = m_provider.loadResource(name);

            if(buffer != null)

                ins = new ByteArrayInputStream(buffer);

        }

        catch(IOException ex)

        {

            

        }



        return ins;

    }



    private Class findLoadedClassEx(String name) throws ClassNotFoundException

    {

        Class classClass = null;

        

        classClass = findCurrentClass(name);

        if (classClass == null)

        {

            classClass = findLoadedClass(name);

            if (classClass == null)

            {

                classClass = findSystemClass(name);

            }

        }

        

        return classClass;

    }



    private Class findCurrentClass(String name)

    {

        Class classClass = null;

        ClassLoader clLoader = getClass().getClassLoader();

        

        if(clLoader != null)

        {

            try

            {

                classClass = clLoader.loadClass(name);

            }

            catch(ClassNotFoundException ex)

            {

            }

        }

        

        return classClass;



    }

}

