import os

def ref(name):
    x = ""
    with open(name, 'r') as fhandle:
        for i in fhandle:
            i2 = i.strip()
            if len(i2) > 1:
                if i2[0] == '/' and i2[1] == '/':
                    continue
            x += i + '\n'
    with open(name, 'w') as fhandle:
        fhandle.write(x)

for dirname,dirs,files in os.walk('.'):
    print files
    for i in files:
        if i[-5:] == '.java':
            ref(os.path.join(dirname,i))

